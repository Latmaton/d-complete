"""精确有理数核验：固定输入 → 常数 → 尾界 → 尺度 → 分段端点。

本模块不搜索参数，也不信任预存的计数结论；所有决定性比较均为整数或
Fraction 比较。失败使用明确异常，因此 python -O 不会关闭核验。
"""
from fractions import Fraction as F
from math import gcd
from numbers import Integral
from parameters import (PARAMETERS, SCALES, INTERVALS, HEIGHT_LIMITS,
                        PAPER_TARGETS, CHUNK, TERMINAL_LIMITS, POSITIVE_SETTINGS)


def _integer(value, name, minimum=None):
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError(f'{name} 必须是整数，实际为 {value!r}')
    value = int(value)
    if minimum is not None and value < minimum:
        raise ValueError(f'{name} 必须至少为 {minimum}，实际为 {value}')
    return value


def _rational(value, name, minimum=None):
    if isinstance(value, bool) or not isinstance(value, (Integral, F)):
        raise TypeError(f'{name} 必须是整数或 Fraction，不能使用浮点数')
    value = F(int(value)) if isinstance(value, Integral) else value
    if minimum is not None and value < minimum:
        raise ValueError(f'{name} 必须至少为 {minimum}，实际为 {value}')
    return value


def _intervals(rows, scale_count, J, p):
    """复制并检查完整分段；不修改 parameters.py 中的原始表。"""
    if not rows:
        raise ValueError('分段表不能为空')
    result = []
    end = None
    for v, row in enumerate(rows, 1):
        if len(row) != 3:
            raise ValueError(f'区间 {v} 必须包含 left, right, choices')
        left, right, choices = row
        left = _rational(left, f'区间 {v} 左端点')
        right = _rational(right, f'区间 {v} 右端点')
        if not 0 < left < right or (end is not None and left != end):
            raise ValueError(f'区间 {v} 必须为正且与前一区间连续')
        if len(choices) != J:
            raise ValueError(f'区间 {v} 必须恰有 J={J} 个选择')
        checked = []
        for j, choice in enumerate(choices):
            if len(choice) != 2:
                raise ValueError(f'区间 {v} 的选择 j={j} 必须为 (i,k)')
            i = _integer(choice[0], f'区间 {v}, j={j} 的 i', 1)
            k = _integer(choice[1], f'区间 {v}, j={j} 的 k')
            if i > scale_count:
                raise ValueError(f'区间 {v}, j={j} 的尺度编号 i={i} 越界')
            checked.append((i, k))
        result.append((left, right, checked))
        end = right
    if end != p * result[0][0]:
        raise ValueError('分段表必须恰好覆盖一个完整的 |p| 乘法周期')
    return result


def read_inputs(p, q):
    """在大型搜索之前检查所有固定输入，接受交换顺序的已支持底数组。"""
    p, q = _integer(p, 'p'), _integer(q, 'q')
    if (p, q) not in PARAMETERS and (q, p) in PARAMETERS:
        p, q = q, p
    pair = p, q
    if pair not in PARAMETERS:
        raise ValueError(f'底数组 {pair} 没有固定输入')
    if abs(p) <= 1 or abs(q) <= 1 or gcd(p, q) != 1:
        raise ValueError('底数绝对值必须大于 1，且互素')
    if len(PARAMETERS[pair]) != 9:
        raise ValueError('PARAMETERS 每行必须恰有九项')
    d, B, ell, z, C, m0, tmax, J, target = PARAMETERS[pair]
    d = _integer(d, 'd', 1)
    if not B or len(B) != len(ell):
        raise ValueError('B 和 ell 必须是等长非空列表')
    B = [_integer(b, f'B[{i}]', 1) for i, b in enumerate(B, 1)]
    ell = [_integer(t, f'ell[{i}]', 1) for i, t in enumerate(ell, 1)]
    z, C = _rational(z, 'z'), _rational(C, 'C', 1)
    if z <= 1:
        raise ValueError('z 必须严格大于 1')
    m0, tmax, J = (_integer(m0, 'm0', 1), _integer(tmax, 't_max', 1),
                   _integer(J, 'J', 1))
    target = _rational(target, '内部目标', 0)
    paper_target = _rational(PAPER_TARGETS[pair], '论文目标', 0)
    if not paper_target <= target < 1:
        raise ValueError('必须有 0 <= 论文目标 <= 内部目标 < 1')
    H_MAX = _integer(HEIGHT_LIMITS[pair], 'H_MAX', 1)
    chunk = _integer(CHUNK, 'CHUNK', 1)
    D0 = _integer(POSITIVE_SETTINGS['denominator'], 'D0', 1)
    params = dict(p=p, q=q, d=d, B=B, ell=ell, z=z, C=C,
                  m0=m0, t_max=tmax, J=J, target=target, paper_target=paper_target,
                  D0=D0, P=abs(p)**d, s=len(B), H_MAX=H_MAX, chunk=chunk)
    if pair not in SCALES or not SCALES[pair]:
        raise ValueError(f'底数组 {pair} 没有尺度表')
    scales = []
    for index, source in enumerate(SCALES[pair], 1):
        if len(source) != 4:
            raise ValueError(f'尺度 {index} 必须包含 H, X, n, e')
        H, X, n, e = source
        H = _integer(H, f'尺度 {index} 的 H', 1)
        X = _rational(X, f'尺度 {index} 的 X')
        n = _integer(n, f'尺度 {index} 的 n', 0)
        e = _integer(e, f'尺度 {index} 的 e', 0)
        if X <= 0:
            raise ValueError(f'尺度 {index} 的 X 必须为正')
        if pair == (5, 2):
            settings = POSITIVE_SETTINGS
            levels = _integer(settings['levels'], 'levels', 1)
            initial = _integer(settings['seed_exponent'], 'seed_exponent', 1)
            increment = _integer(settings['width_increment'], 'width_increment', 1)
            grid = _integer(settings['grid'], 'grid', 1)
            if e not in range(initial, initial + levels * increment, increment):
                raise ValueError(f'尺度 {index} 的 e 没有对应正例区间表')
            column = X * grid / abs(p)**e
            if column.denominator != 1 or not 0 < column <= 2 * grid:
                raise ValueError(f'尺度 {index} 的 X 不在对应区间表的有效网格上')
        else:
            if e != 0 or X.denominator != 1:
                raise ValueError(f'有符号尺度 {index} 必须有 e=0 且 X 为整数')
            if pair in TERMINAL_LIMITS:
                limit = _integer(TERMINAL_LIMITS[pair], '终端窗口', 1)
                if X > limit:
                    raise ValueError(f'尺度 {index} 的 X 超出终端窗口')
            elif pair in ((7, -2), (-7, -2)):
                if H != 1 or X != 7:
                    raise ValueError('七进制特例只提供 H=1, X=7 的两个单项表示')
            else:
                raise ValueError(f'底数组 {pair} 没有终端计数方案')
        scales.append(dict(H=H, X=X, n=n, count_exponent=e,
                           tail_terms=min(H, tmax)))
    if pair not in INTERVALS:
        raise ValueError(f'底数组 {pair} 没有分段表')
    intervals = _intervals(INTERVALS[pair], len(scales), J, abs(p))
    constants(params)  # 收缩条件与乘法阶在大型搜索之前检查。
    return params, scales, intervals


def constants(params):
    """只依赖固定输入；应在剩余类搜索、终端计数之前执行。"""
    p, q = _integer(params['p'], 'p'), _integer(params['q'], 'q')
    if abs(p) <= 1 or abs(q) <= 1 or gcd(p, q) != 1:
        raise ValueError('计算常数要求互素且绝对值大于 1 的底数')
    P = _integer(params['P'], 'P', 2)
    B = [_integer(b, 'B_i', 1) for b in params['B']]
    ell = [_integer(t, 'ell_i', 1) for t in params['ell']]
    if not B or len(B) != len(ell):
        raise ValueError('B 和 ell 必须是等长非空列表')
    s = len(B)
    c = F(abs(q)**sum(ell), P**s)
    if c >= 1:
        raise ValueError(f'收缩条件 c < 1 不成立：c={c}')
    A = sum((F(B[i]*abs(q)**(sum(ell[i:])-1), P**(s-i))
             for i in range(s)), F(0)) / (1-c)
    kappa = 1 if p > 0 and q > 0 else 2
    for order in range(1, abs(q) + 1):
        if pow(p, order, abs(q)) == 1:
            break
    else:
        raise ValueError('无法确定 p 模 |q| 的乘法阶')
    theta = F(kappa*order, abs(q))
    return c, A, kappa, theta


def tails(params, hist):
    """指数矩给出初始尾界，按完整周期递推并向上取整。"""
    P, B, ell = params['P'], params['B'], params['ell']
    z, C, D0 = params['z'], params['C'], params['D0']
    s = len(B)
    moments = []
    checked_hist = {}
    for i in range(s):
        if B[i] not in hist:
            raise ValueError(f'缺少 B={B[i]} 的高度直方图')
        row = {_integer(h, '直方图高度', 0): _integer(number, '直方图计数', 0)
               for h, number in hist[B[i]].items()}
        if sum(row.values()) != P or row.get(0) != 1:
            raise ValueError(f'B={B[i]} 的直方图须覆盖 P 个剩余类且高度 0 恰有一个')
        checked_hist[B[i]] = row
        moments.append(sum((number*z**(h-ell[i])
                            for h, number in row.items()), F(0))/P)
    g = F(1)
    for value in moments:
        g *= value
    partial = F(1)
    Lambda = F(1)
    for i in range(s-1, 0, -1):
        partial *= moments[i]
        Lambda = max(Lambda, partial)
    if g >= 1 or Lambda > C:
        raise ValueError(f'指数矩条件不成立：须 g < 1 且 Lambda_s <= C；g={g}, Lambda_s={Lambda}')

    # 每一步最大访问下标为 t+ell[i]；提前保留完整周期所需的额外项。
    length = params['t_max'] + params['m0']*sum(ell)
    w = [D0]
    for t in range(1, length+1):
        value = D0*min(F(1), C/z**t)
        w.append(-(-value.numerator // value.denominator))
    for step in range(params['m0']*s):
        i = step % s
        length -= ell[i]
        new = [D0]
        for t in range(1, length+1):
            total = 0
            for h, number in checked_hist[B[i]].items():
                u = t+ell[i]-h
                total += number*(D0 if u <= 0 else w[u])
            new.append(-(-total // P))
        w = new
    w = [F(number, D0) for number in w]
    if len(w) != params['t_max']+1 or w[0] != 1:
        raise RuntimeError('尾界递推的长度或初值错误')
    if any(not 0 <= w[t+1] <= w[t] <= 1 for t in range(len(w)-1)):
        raise RuntimeError('尾界必须在 [0,1] 内单调不增')
    return w, g, Lambda


def scale_coefficients(params, scales, w, terminal, A):
    """由终端计数下界和尾界得到安全的有理尺度，原地填入 a,b。"""
    p, q, D0 = abs(params['p']), abs(params['q']), params['D0']
    A = _rational(A, 'A', 0)
    w = [_rational(value, f'w[{t}]', 0) for t, value in enumerate(w)]
    if not w or w[0] != 1 or any(w[t+1] > w[t] for t in range(len(w)-1)):
        raise ValueError('尾界必须从 1 开始单调不增')
    for index, row in enumerate(scales, 1):
        H, X, n = row['H'], row['X'], row['n']
        terms = _integer(row['tail_terms'], 'tail_terms', 1)
        if terms >= len(w) or terms > H:
            raise ValueError(f'尺度 {index} 所需尾界长度不足或高度非法')
        boundary = (A*q**H+X)/p**n
        scaled = D0*boundary
        # 严格取上方网格点；即使 boundary 已在网格上，也必须加 1。
        row['a'] = F(scaled.numerator//scaled.denominator+1, D0)
        beta = F(0)
        for v in range(terms):
            weight = w[v]-w[v+1]
            if weight > 0:
                key = H-v, X
                if key not in terminal:
                    raise ValueError(f'尺度 {index} 缺少终端计数 {key}')
                lower = _rational(terminal[key], f'终端计数 {key}', 0)
                beta += weight*lower
        scaled = D0**2*beta/p**n
        row['b'] = F(scaled.numerator//scaled.denominator, D0**2)
        if row['a'] <= boundary or row['b'] <= 0:
            raise ValueError(f'尺度 {index} 未得到严格上方 a 和正下界 b')


def density(params, scales, intervals, kappa, theta, records=None):
    """检查每段两端的精确值；可将全部端点和逐 j 贡献写入 records。"""
    if records is not None and not isinstance(records, list):
        raise TypeError('records 必须为 list 或 None')
    p, q, J = abs(params['p']), abs(params['q']), params['J']
    kappa = _integer(kappa, 'kappa', 1)
    theta = _rational(theta, 'theta', 0)
    intervals = _intervals(intervals, len(scales), J, p)
    minimum = None
    for v, (left, right, choices) in enumerate(intervals, 1):
        for y in (left, right):
            total = F(0)
            contributions = []
            for j, (i, k) in enumerate(choices):
                a = _rational(scales[i-1]['a'], f'尺度 {i} 的 a', 0)
                b = _rational(scales[i-1]['b'], f'尺度 {i} 的 b', 0)
                factor = F(p)**k
                penalty = theta*max(F(0), factor*a-y/q**j)
                contribution = factor*b-penalty
                total += contribution
                if records is not None:
                    contributions.append(dict(j=j, i=i, k=k, factor=factor,
                                              a=a, b=b, penalty=penalty,
                                              contribution=contribution))
            value = total/(kappa*(1-F(1, q**J))*y)
            if records is not None:
                records.append(dict(interval_index=v, y=y, left=left, right=right,
                                    value=value, numerator=total,
                                    contributions=contributions))
            minimum = value if minimum is None else min(minimum, value)
    if minimum <= params['target']:
        raise ValueError(f'端点最小值 {minimum} 没有严格超过内部目标 {params["target"]}')
    return minimum
