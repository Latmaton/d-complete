"""剩余类构造：逐条核验表示，最终只保留后续使用的计数。

阅读顺序：verify_family → signed_families；两个大例子另用布尔递推
和正整数高度递推。后两者的 NumPy 运算只是同时处理一批整数。
"""
from fractions import Fraction as F
from math import gcd
import numpy as np
from parameters import CHUNK, POSITIVE_SETTINGS


# 这些是计算参数，不是论文中的数学参数。
PROGRESS_INTERVAL = 4096  # 每检查这么多个余数，显示一次进度
UNREPRESENTED = 255       # 高度数组中的特殊标记，表示没有找到表示
INT64_MAX = 2**63 - 1
UINT32_MAX = 2**32 - 1


def check_integer(value, name, minimum=None):
    """计算参数必须是整数，不能由浮点数悄悄取整。"""
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)):
        raise ValueError(name + ' 必须为整数')
    value = int(value)
    if minimum is not None and value < minimum:
        raise ValueError(name + ' 超出允许范围')
    return value


def check_bases(p, q):
    p = check_integer(p, 'p')
    q = check_integer(q, 'q')
    if abs(p) < 2 or abs(q) < 2 or gcd(p, q) != 1:
        raise ValueError('底数的绝对值须至少为 2，且两底数互素')
    return p, q


def check_bounds(bounds):
    """大小界使用整数或 Fraction，始终保持精确。"""
    bounds = list(bounds)
    if not bounds or any(isinstance(B, bool) or not isinstance(B, (int, F))
                         or B < 0 for B in bounds):
        raise ValueError('大小界必须是非负整数或精确有理数')
    return sorted(set(bounds))


def verify_family(p, q, d, r, terms, B):
    """检查一条有理数表示，返回高度。检查结束后无需保存这条表示。

    terms 是 (alpha, gamma) 的序列，对应各项 p**alpha / q**gamma。
    两列指数都严格递增，alpha < d，和的绝对值不超过 B。
    """
    p, q = check_bases(p, q)
    d = check_integer(d, 'd', 1)
    r = check_integer(r, 'r', 0)
    check_bounds([B])
    P = abs(p)**d
    if r >= P:
        raise ValueError('剩余类必须位于 0 到 P-1')
    terms = tuple(terms)
    value = F(0)                  # 实际的有理数和
    residue = 0                   # 同一个和模 P 的值，最后统一取余数
    last_a = -1                   # 上一项的 alpha
    last_b = -1                   # 上一项的 gamma
    for a, b in terms:
        a = check_integer(a, 'alpha', 0)
        b = check_integer(b, 'gamma', 0)
        if not (last_a < a < d and last_b < b):
            raise ValueError('指数范围或严格递增条件不成立')
        value += F(p**a, q**b)
        # pow(q, -b, P) 是 q**b 模 P 的逆元，不是浮点数 q**(-b)。
        residue += pow(p, a, P) * pow(q, -b, P)
        last_a = a
        last_b = b
    if abs(value) > B or residue % P != r or (r == 0 and terms):
        raise ValueError('剩余类见证未通过检验')
    return last_b + 1             # 空表示返回0，否则返回最大的gamma加1


def signed_families(params, verbose=True):
    """逐个搜索剩余类并核验。返回 hist[B][h]：高度等于h的余数个数。"""
    p, q = check_bases(params['p'], params['q'])
    d = check_integer(params['d'], 'd', 1)
    Hmax = check_integer(params['H_MAX'], 'H_MAX', 1)
    bounds = check_bounds(params['B'])  # 相同的B只搜索一次，从小到大处理
    P = abs(p)**d
    modulus = [abs(p)**e for e in range(d + 1)]
    inverse = [[0] * Hmax]       # e=0时模数为1，不需要真正的逆元
    for e in range(1, d + 1):
        inverse.append([pow(q, -gamma_min, modulus[e]) for gamma_min in range(Hmax)])
    geometry = {}                # 相同H共用整数和的上下界表

    def divide_interval(lo, hi):
        """求所有满足 lo <= p*x <= hi 的整数x的闭区间。"""
        if p < 0:
            lo, hi = -hi, -lo
        lower = -((-lo) // abs(p))  # ceil(lo / abs(p))
        upper = hi // abs(p)       # floor(hi / abs(p))
        return lower, upper

    def search(r, B, H):
        """在 gamma < H 的范围内寻找一个表示，失败返回None。"""
        if r == 0:
            return ()
        if H not in geometry:
            # 把有理数和乘以 q**(H-1)，得到整数和。
            powers = [q**(H - 1 - gamma_min) for gamma_min in range(H)]
            # low[e][gamma_min]、high[e][gamma_min]：不加同余限制时的最小/最大整数和。
            # 此处的指数范围是 0 <= alpha < e，gamma_min <= gamma < H。
            # 空和0也包括在内。e=0或g=H时没有可选项。
            low = [[0] * (H + 1) for _ in range(d + 1)]
            high = [[0] * (H + 1) for _ in range(d + 1)]
            for e in range(1, d + 1):
                for gamma_min in range(H - 1, -1, -1):
                    # 情形一：不出现alpha=0，把所有项除以p。
                    without_low, without_high = sorted(
                        (p * low[e - 1][gamma_min], p * high[e - 1][gamma_min]))
                    # 情形二：出现(alpha,gamma)=(0,gamma_min)，删掉这一项再除以p。
                    with_low, with_high = sorted(
                        (p * low[e - 1][gamma_min + 1], p * high[e - 1][gamma_min + 1]))
                    with_low += powers[gamma_min]
                    with_high += powers[gamma_min]
                    # 情形三：所有gamma都大于g。
                    low[e][gamma_min] = min(without_low, with_low, low[e][gamma_min + 1])
                    high[e][gamma_min] = max(without_high, with_high, high[e][gamma_min + 1])
            geometry[H] = powers, low, high
        powers, low, high = geometry[H]
        failures = set()         # 本次搜索中已经确定无解的状态

        def dfs(e, residue, gamma_min, lo, hi):
            """处理剩下e个p指数，分母指数从g开始，整数和在[lo,hi]内。"""
            lo = max(lo, low[e][gamma_min])
            hi = min(hi, high[e][gamma_min])
            if lo > hi:
                return None
            if residue == 0 and lo <= 0 <= hi:
                return ()       # 空表示已经满足当前剩余问题
            if e == 0:
                return None
            key = (e, residue, gamma_min, lo, hi)
            if key in failures:
                return None
            if residue % abs(p) == 0:
                # 模p为0时，不能出现alpha=0的项：该项模p是一个单位。
                lower, upper = divide_interval(lo, hi)
                smaller_residue = (residue // p) % modulus[e - 1]
                answer = dfs(e - 1, smaller_residue, gamma_min, lower, upper)
                if answer is not None:
                    return answer
            else:
                # alpha=0必出现一次，尝试其分母指数gamma。
                for gamma in range(gamma_min, H):
                    difference = (residue - inverse[e][gamma]) % modulus[e]
                    if difference % abs(p):
                        continue
                    lower, upper = divide_interval(
                        lo - powers[gamma], hi - powers[gamma])
                    smaller_residue = (difference // p) % modulus[e - 1]
                    answer = dfs(e - 1, smaller_residue, gamma + 1, lower, upper)
                    if answer is not None:
                        # 已经去掉d-e个p因子，所以实际alpha是d-e。
                        return ((d - e, gamma),) + answer
            failures.add(key)
            return None

        # 被搜索的和是整数，所以非整数大小界可直接向下取整。
        # 这一步对B为Fraction时也精确，不使用float。
        size = F(B) * abs(q)**(H - 1)
        integer_bound = size.numerator // size.denominator
        return dfs(d, r, 0, -integer_bound, integer_bound)

    hist = {B: {0: 1} for B in bounds}  # 零余数使用空表示，高度为0
    for r in range(1, P):
        best = None
        for B in bounds:
            # B 增大后，前一条表示仍可用。第一组 B 直接检查高度上限。
            if best is None:
                best = search(r, B, Hmax)
                if best is None:
                    raise RuntimeError('有剩余类尚未找到表示')
            # 二分找到最小可行高度：lo 不可行，hi 可行。
            lo = 0
            hi = best[-1][1] + 1
            while hi - lo > 1:
                mid = (lo + hi) // 2
                answer = search(r, B, mid)
                if answer is None:
                    lo = mid
                else:
                    best = answer
                    hi = answer[-1][1] + 1
            h = verify_family(p, q, d, r, best, B)
            hist[B][h] = hist[B].get(h, 0) + 1
        # 不保存本轮的r和完整链，仅累计后续需要的高度计数。
        if verbose and (r % PROGRESS_INTERVAL == 0 or r == P - 1):
            print('  已检查', r + 1, '/', P, flush=True)
    if any(sum(row.values()) != P for row in hist.values()):
        raise RuntimeError('高度计数总数不符')
    return hist


def boolean_families(params, verbose=True, chunk=CHUNK):
    """大小条件自动成立时，只记录表示是否存在，不保存具体表示链。"""
    p, q = check_bases(params['p'], params['q'])
    d = check_integer(params['d'], 'd', 1)
    Hmax = check_integer(params['H_MAX'], 'H_MAX', 1)
    chunk = check_integer(chunk, 'chunk', 1)
    bounds = check_bounds(params['B'])
    if min(bounds) < abs(p)**(d - 1):
        raise ValueError('此处不能省略绝对值约束')
    P = abs(p)**d
    if max(abs(p), abs(q)) * P > INT64_MAX:
        raise ValueError('当前布尔递推的整数下标可能超出int64范围')
    # previous[e]存上一高度H-1的存在性，current[e]存当前高度H。
    previous = [np.zeros(abs(p)**e, dtype=bool) for e in range(d + 1)]
    current = [row.copy() for row in previous]
    for row in previous + current:
        row[0] = True           # 任意宽度和高度都允许空表示
    hist = {0: 1}
    total = 1
    for H in range(1, Hmax + 1):
        for e in range(1, d + 1):
            m = abs(p)**e       # 当前宽度的模数
            small = abs(p)**(e - 1)
            for left in range(0, m, chunk):
                right = min(left + chunk, m)
                r = np.arange(left, right, dtype=np.int64)
                # 情形一：所有gamma>=1，乘以q后高度减1。
                answer = previous[e][(q * r) % m].copy()
                # 情形二：所有alpha>=1，除以p后宽度减1。
                divisible = r % abs(p) == 0
                answer[divisible] |= current[e - 1][(r[divisible] // p) % small]
                # 情形三：出现(0,0)，删去1、除以p、再乘以q。
                has_one = r % abs(p) == 1
                smaller_residue = (q * ((r[has_one] - 1) // p)) % small
                answer[has_one] |= previous[e - 1][smaller_residue]
                current[e][left:right] = answer
        count = int(np.count_nonzero(current[d]))
        if count < total:
            raise RuntimeError('累计高度计数下降')
        if count > total:
            hist[H] = count - total
        total = count
        if verbose:
            print('  H =', H, '，已覆盖', total, '/', P, flush=True)
        previous, current = current, previous  # 交换数组，复用内存
        if total == P:
            return {B: dict(hist) for B in bounds}
    raise RuntimeError('高度上限内没有覆盖全部剩余类')


def odd_heights(limit, width, chunk=CHUNK, verbose=True):
    """计算奇数 n 的最小高度 h_min,k(n)，最后返回 k=width 的结果。

    previous[i] = h_min,k-1(2*i+1)，只读取，不修改。
    current[i]  = h_min,k(2*i+1)，只写入本轮结果。
    不可表示的高度用 255 记录，因此只保存小于 255 的有限高度。
    """
    limit = check_integer(limit, 'limit', 1)
    width = check_integer(width, 'width', 1)
    chunk = check_integer(chunk, 'chunk', 1)
    if limit >= 2**32 or width > 20:
        raise ValueError('有限高度表超出此实现的范围')
    # 两个数组各存一轮高度。每项占1字节，空间比旧版增加一份高度表。
    previous = np.full((limit + 1) // 2, UNREPRESENTED, dtype=np.uint8)
    current = np.empty_like(previous)

    for k in range(1, width + 1):
        power = 5**(k - 1)
        # 不使用新项 5**(k-1) 时，h_min,k(n) 至多为 h_min,k-1(n)。
        current[:] = previous

        # 现在读 previous，写 current，因而直接从小到大遍历，无须倒序。
        for left in range((power - 1) // 2, len(previous), chunk):
            right = min(left + chunk, len(previous))
            n = 2 * np.arange(left, right, dtype=np.int64) + 1
            parent = (n - power) // 2

            # parent=2**exponent*odd；当 parent=0 时，下面单独赋值。
            odd = parent.copy()
            exponent = np.zeros(len(parent), dtype=np.int64)
            even = (odd > 0) & (odd % 2 == 0)
            while np.any(even):
                odd[even] //= 2
                exponent[even] += 1
                even = (odd > 0) & (odd % 2 == 0)

            indices = np.maximum(0, (odd - 1) // 2)
            # 这里明确读取上一轮：1 + h_min,k-1((n-5**(k-1))/2)。
            candidate = previous[indices].astype(np.int64) + exponent + 1
            candidate[parent == 0] = 1
            candidate = np.minimum(candidate, UNREPRESENTED)
            # 与不用新项的旧高度取最小，写入本轮数组。
            current[left:right] = np.minimum(previous[left:right], candidate)

        # 下一轮继续使用同两块内存；交换的是变量指向，不是拷贝数组。
        previous, current = current, previous
        if verbose:
            print('  有限高度表 k =', k, '/', width, flush=True)
    return previous


def positive_families(cap=POSITIVE_SETTINGS['cap'], d=11,
                      bounds=(10,11,12,14,22), hmax=31,
                      size_grid=POSITIVE_SETTINGS['size_grid'],
                      chunk=CHUNK, verbose=True):
    """为(5,2)检索S/2**(h-1)，只保存高度分布与高度/大小联合计数。

    先按h从小到大，再按奇数S从小到大，选取每个余数首次出现的表示。
    不同批次也共用seen，所以每个余数只累计一次。
    """
    cap = check_integer(cap, 'cap', 1)
    d = check_integer(d, 'd', 1)
    hmax = check_integer(hmax, 'hmax', 1)
    size_grid = check_integer(size_grid, 'size_grid', 1)
    chunk = check_integer(chunk, 'chunk', 1)
    if cap >= 2**32 or d > 20 or hmax >= UNREPRESENTED:
        raise ValueError('宽度、高度、网格或分块大小不合法')
    bounds = sorted({check_integer(B, 'B', 1) for B in bounds})
    if not bounds:
        raise ValueError('正例的大小分组不能为空')
    P = 5**d
    # 乘法发生在NumPy定长整数中，因此在分配大数组前先检查界。
    if P > UINT32_MAX or cap * (P - 1) > INT64_MAX or cap * size_grid > INT64_MAX:
        raise ValueError('当前参数可能使余数计算或联合计数发生整数溢出')
    if max(bounds) * 2**(hmax - 1) > INT64_MAX:
        raise ValueError('大小比较超出此int64实现的范围')
    if chunk * 2 >= P:
        chunk = max(1, (P - 1) // 2)  # 保证一批中的不同S给出不同余数
    heights = odd_heights(cap, d, chunk=chunk, verbose=verbose)
    histogram = {}
    joint = {}
    for B in bounds:
        seen = np.zeros(P, dtype=bool)
        seen[0] = True
        # counts[h,b]记录高度h且floor(size_grid*sigma)=b的余数个数。
        counts = np.zeros((hmax + 1, B * size_grid + 1), dtype=np.uint32)
        counts[0, 0] = 1
        covered = 1
        for h in range(1, hmax + 1):
            denominator = 2**(h - 1)
            inverse = pow(denominator, -1, P)
            last = (min(cap, B * denominator) + 1) // 2  # 要检查的奇数个数
            for left in range(0, last, chunk):
                right = min(left + chunk, last)
                S = 2 * np.arange(left, right, dtype=np.int64) + 1
                residues = (S * inverse) % P
                keep = (heights[left:right] <= h) & ~seen[residues]
                if np.any(keep):
                    values = S[keep]
                    accepted = residues[keep]
                    if np.any(values > B * denominator):
                        raise RuntimeError('余数族大小界不成立')
                    seen[accepted] = True
                    bins = values * size_grid // denominator
                    added = np.bincount(bins)
                    counts[h, :len(added)] += added.astype(np.uint32)
                    covered += len(accepted)
                if covered == P:
                    break
            if verbose:
                print('  B =', B, '，h =', h, '，覆盖', covered, '/', P, flush=True)
            if covered == P:
                break
        if covered != P or not np.all(seen):
            raise RuntimeError('有剩余类未覆盖，不可继续验证密度')
        row = {}
        for h in range(hmax + 1):
            number = int(counts[h].sum(dtype=np.uint64))
            if number:
                row[h] = number
        if sum(row.values()) != P or row.get(0) != 1:
            raise RuntimeError('余数族计数不符')
        histogram[B] = row
        joint[B] = counts
    return histogram, joint


def residue_counts(params, verbose=True):
    """选择适合当前参数的算法，统一返回(高度分布, 联合计数或None)。"""
    pair = check_bases(params['p'], params['q'])
    chunk = check_integer(params.get('chunk', CHUNK), 'chunk', 1)
    d = check_integer(params['d'], 'd', 1)
    bounds = check_bounds(params['B'])
    if pair == (5, 2):
        hist, joint = positive_families(
            cap=POSITIVE_SETTINGS['cap'], d=d,
            bounds=bounds, hmax=params['H_MAX'],
            size_grid=POSITIVE_SETTINGS['size_grid'], chunk=chunk, verbose=verbose)
        return hist, joint
    if min(bounds) >= abs(pair[0])**(d - 1):
        return boolean_families(params, verbose=verbose, chunk=chunk), None
    return signed_families(params, verbose=verbose), None
