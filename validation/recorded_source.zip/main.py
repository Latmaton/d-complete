"""从头构造并核验八组固定实例。例：python main.py -2 -3。"""
import argparse
from datetime import datetime, timezone
from pathlib import Path
import time

from parameters import (PARAMETERS, POSITIVE_SETTINGS, TERMINAL_LIMITS,
                        CHUNK, PAPER_TARGETS)
from arithmetic import read_inputs, constants, tails, scale_coefficients, density
from residues import residue_counts
from terminals import terminal_counts
from reporting import (write_json, source_hashes, environment, residue_report,
                       tail_report, terminal_report, scale_report, endpoint_report)


def resource_notes(pair):
    """只估计主要数组大小，不把它称为进程峰值内存。"""
    p, q = pair
    if pair == (5, 2):
        settings = POSITIVE_SETTINGS
        base = 5 ** settings['seed_exponent']
        return {'odd_seed_count': base,
                'two_seed_height_arrays_bytes': 2 * base,
                'residue_modulus': 5 ** PARAMETERS[pair][0],
                'note': '正例规模较大。这里只列主要高度数组，不含联合计数和临时数组。'}
    if pair in TERMINAL_LIMITS:
        limit = TERMINAL_LIMITS[pair]
        length = (2 * limit) // 3 + 1 if pair == (-2, 3) else 2 * limit + 1
        return {'terminal_window_radius': limit,
                'two_terminal_boolean_arrays_bytes_at_most': 2 * length,
                'note': '还需剩余类搜索和临时数组所用内存。'}
    d = PARAMETERS[pair][0]
    return {'two_residue_boolean_tables_bytes':
            2 * sum(abs(p) ** e for e in range(d + 1)),
            'note': '终端下界直接来自两个单项表示。'}


def parameter_check(pair, chunk=CHUNK):
    params, scales, intervals = read_inputs(*pair)
    if not isinstance(chunk, int) or isinstance(chunk, bool) or chunk < 1:
        raise ValueError('chunk 必须为正整数')
    params['chunk'] = chunk
    # 这些检查便宜，应在任何大规模数组构造之前完成。
    const = constants(params)
    return params, scales, intervals, const


def run_case(pair, output='results', chunk=CHUNK, verbose=True, save_arrays=False):
    params, scales, intervals, const = parameter_check(pair, chunk)
    pair = params['p'], params['q']
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    folder = Path(output) / (f'{pair[0]}_{pair[1]}_' + stamp)
    folder.mkdir(parents=True, exist_ok=False)
    hashes = source_hashes()
    summary = {'status': 'running', 'pair': pair,
               'started_utc': stamp, 'source_sha256': hashes,
               'environment': environment(), 'paper_target': params['paper_target'],
               'verification_target': params['target'], 'stages_seconds': {},
               'resources': resource_notes(pair)}
    write_json(folder / 'summary.json', summary)
    write_json(folder / 'parameters.json', {'parameters': params,
               'scales': scales, 'intervals': intervals,
               'positive_settings': POSITIVE_SETTINGS if pair == (5, 2) else None})
    c, A, kappa, theta = const
    write_json(folder / 'constants.json', {'c': c, 'A': A, 'kappa': kappa, 'theta': theta})
    start = time.perf_counter()
    stage = 'residues'
    try:
        print(f'\n底数 {pair}，结果目录 {folder}', flush=True)
        print('1/4 从头构造剩余类族', flush=True)
        now = time.perf_counter()
        hist, joint = residue_counts(params, verbose=verbose)
        summary['stages_seconds'][stage] = time.perf_counter() - now
        residue_report(folder, hist, joint, save_arrays)
        write_json(folder / 'summary.json', summary)

        stage = 'tails'
        print('2/4 核验指数矩并计算尾界', flush=True)
        now = time.perf_counter()
        w, g, Lambda = tails(params, hist)
        summary['stages_seconds'][stage] = time.perf_counter() - now
        tail_report(folder, w, g, Lambda)
        write_json(folder / 'summary.json', summary)

        stage = 'terminals'
        print('3/4 从头构造终端计数下界', flush=True)
        now = time.perf_counter()
        terminal = terminal_counts(params, scales, joint, verbose=verbose)
        summary['stages_seconds'][stage] = time.perf_counter() - now
        terminal_report(folder, terminal)
        # 大型联合表此后不再使用，让下一组可回收其内存。
        del joint
        write_json(folder / 'summary.json', summary)

        stage = 'density'
        print('4/4 计算尺度系数并核验所有端点', flush=True)
        now = time.perf_counter()
        scale_coefficients(params, scales, w, terminal, A)
        records = []
        lower = density(params, scales, intervals, kappa, theta, records=records)
        summary['stages_seconds'][stage] = time.perf_counter() - now
        scale_report(folder, scales)
        endpoint_report(folder, records)
        if source_hashes() != hashes:
            raise RuntimeError('运行期间核心源码发生变化，请用固定版本重新运行')
        summary.update(status='passed', lower_bound=lower,
                       terminal_request_count=len(terminal),
                       scale_count=len(scales), interval_count=len(intervals),
                       endpoint_count=len(records),
                       elapsed_seconds=time.perf_counter() - start)
        write_json(folder / 'summary.json', summary)
        print('全部核验通过。下密度 >=', lower, '>', params['target'], flush=True)
        print('小数仅供阅读：', float(lower), flush=True)
        return summary, folder
    except BaseException as error:
        summary.update(status='interrupted' if isinstance(error, KeyboardInterrupt) else 'failed',
                       failed_stage=stage, error=type(error).__name__ + ': ' + str(error),
                       elapsed_seconds=time.perf_counter() - start)
        write_json(folder / 'summary.json', summary)
        raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('p', type=int, nargs='?')
    parser.add_argument('q', type=int, nargs='?')
    parser.add_argument('--all', action='store_true', help='依次从头核验八组实例')
    parser.add_argument('--list', action='store_true', help='列出支持的实例')
    parser.add_argument('--check-parameters', action='store_true', help='只核验参数与廉价常数条件')
    parser.add_argument('--plan', action='store_true', help='显示实例和主要数组规模，不开始完整计算')
    parser.add_argument('--output', default='results', help='本次结果目录的父目录')
    parser.add_argument('--chunk', type=int, default=CHUNK, help='分块位置数，仅影响临时内存')
    parser.add_argument('--quiet', action='store_true', help='只显示主要步骤')
    parser.add_argument('--save-arrays', action='store_true', help='另外保存正例的联合计数压缩数组')
    args = parser.parse_args(argv)
    if args.chunk < 1:
        parser.error('--chunk 必须为正整数')
    if (args.p is None) != (args.q is None):
        parser.error('请同时给出 p 和 q')
    if args.all and args.p is not None:
        parser.error('--all 与单组底数不可同时使用')
    if args.list:
        for pair in PARAMETERS:
            print(pair, '论文目标', PAPER_TARGETS[pair], '核验目标', PARAMETERS[pair][-1])
        return 0
    if args.all or ((args.check_parameters or args.plan) and args.p is None):
        pairs = list(PARAMETERS)
    elif args.p is not None:
        pair = args.p, args.q
        if pair not in PARAMETERS and pair[::-1] in PARAMETERS:
            pair = pair[::-1]
        if pair not in PARAMETERS:
            parser.error('没有这组固定参数，请运行 --list')
        pairs = [pair]
    else:
        parser.print_help()
        return 0
    if args.check_parameters or args.plan:
        for pair in pairs:
            parameter_check(pair, args.chunk)
            print(pair, '参数与常数检查通过')
            if args.plan:
                print(resource_notes(pair))
        print('此模式没有验证剩余类、终端或最终密度下界。')
        return 0
    try:
        for pair in pairs:
            run_case(pair, args.output, args.chunk, not args.quiet, args.save_arrays)
    except KeyboardInterrupt:
        print('\n计算已中断，已有阶段记录已保存。')
        return 130
    except (ValueError, RuntimeError, OverflowError, MemoryError) as error:
        print('本次核验未完成：', error)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
